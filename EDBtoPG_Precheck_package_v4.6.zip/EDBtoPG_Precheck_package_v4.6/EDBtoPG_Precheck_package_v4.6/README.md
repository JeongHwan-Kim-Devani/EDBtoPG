# EDBtoPG: EPAS to PostgreSQL Migration Precheck Tool

<p align="center">
  <img src="./assets/images/main_illustration.png" alt="Main Illustration" width="400">
</p>

## 개요
`EDBtoPG`는 EPAS(EnterpriseDB Advanced Server) 환경에서 PostgreSQL로 마이그레이션하기 전에
호환성 이슈를 사전 진단하고, 결과를 HTML/TSV 리포트로 생성하는 도구입니다.

## 담당자
|역할|담당자|
|---------|---|
| 총괄 / 기획 / 설계 | 최영준 (yjchoi@rockplace.com)|
| 디자인 / 개발 / 관리 | 김정환 (jeonghwan.kim@rockplace.com)|
| 품질 / 인프라 / 지원 | 강홍용 (hykang@rockplace.com)|


## 주요 기능
- 파라미터 점검: 기본값 대비 현재값 비교 및 변경 영향 확인
- Oracle/EDB 호환 키워드 탐지: 객체 소스 내 주요 키워드 매칭
- 데이터 타입/객체 분석: `RAW`, `CLOB`, `BFILE` 등 점검
- 정책/고급 기능 점검: Synonym, RLS, Profile, Resource Group, DBLink
- 시각화 리포트: Summary/Details 카드, 상태 배지, 영향도 도넛 차트

## 요구 사항
- OS: Bash 실행 가능 환경
- DB Client: `psql`
- Optional: `python3` (특정 소스 하이라이팅 보조)

## 실행 방법
```bash
bash EPAS_PRECHECK/epas_precheck_v4.6.sh -d <DBNAME> -U <USER> -o ./out
```

### 자주 쓰는 옵션
- `-h, --host`: DB 호스트 (기본값 `localhost`)
- `-p, --port`: DB 포트 (기본값 `5444`)
- `-W, --password`: DB 비밀번호 (권장: 환경변수 `PGPASSWORD`)
- `-c, --compress`: `tar` 또는 `gz`
- `--connect-timeout`: 연결 타임아웃(초)

### v4.6 Update Notes
- 현재 권장 스크립트: `EPAS_PRECHECK/epas_precheck_v4.6.sh`
- `pg_policy` 카탈로그가 없는 환경에서도 정책 요약 분석이 안전하게 동작하도록 개선
- EPAS 9.4/9.5 호환성 개선:
  - `to_jsonb(...)`/`jsonb_each_text(...)` 의존 구문을 `row_to_json(...)`/`json_each_text(...)` 기반으로 변경
  - `pg_proc.proparallel` 미존재 환경에서 안전하게 동작하도록 처리
- EPAS 11+ 호환성 개선:
  - `prokind` 탐지 분기 안정화로 `proisagg` 미존재 오류 방지
- 유지보수성 개선:
  - 반복 하드코딩된 시스템 스키마 제외 목록을 단일 변수(`SYSTEM_SCHEMA_LIST`)로 통합
  - SQL 템플릿 치환(`__SYSTEM_SCHEMA_LIST__`)으로 일관성 강화

## 출력물 안내
출력 디렉터리에는 아래 파일이 생성됩니다.
- `<DBNAME>.html`: 최종 메인 리포트
- `<DBNAME>_source.html`: 소스 네비게이터 인덱스
- `<DBNAME>_sources/`: 객체별 소스 HTML
- `*.tsv`: 중간/분석 데이터

### 출력 샘플 (v2.0 최종 디자인)
<p align="center">
  <img src="./assets/images/precheck_report_sample1.png" alt="EPAS Precheck v2.0 output sample" width="1200">
  <img src="./assets/images/precheck_report_sample2.png" alt="EPAS Precheck v2.0 output sample" width="1200">
</p>

## 디자인 문서
- 최종 시안 문서: `design/README.md`
- 최종 프로토타입: `design/epas_precheck_v2.0_prototype.html`

## 참고
- 레거시 스크립트/SQL 백업: `EPAS_PRECHECK/.dummy/`
